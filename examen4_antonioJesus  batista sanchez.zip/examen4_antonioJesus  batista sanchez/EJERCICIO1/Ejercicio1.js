//SOLO ME HA DADO TIEMPO DE CREA LOS PROMTS Y CONVERTILOS EN UN ARRAY

let palabra1 = prompt("Introduce la primera cadena de caracteres:");
let palabra2 = prompt("Introduce la primera cadena de caracteres:");
let palabra3 = prompt("Introduce la primera cadena de caracteres:");
let palabra4 = prompt("Introduce la primera cadena de caracteres:");
let palabra5 = prompt("Introduce la primera cadena de caracteres:");
let palabra6 = prompt("Introduce la primera cadena de caracteres:");
let palabra7 = prompt("Introduce la primera cadena de caracteres:");
let palabra8 = prompt("Introduce la primera cadena de caracteres:");
function MostrarPalabras(palabras) {
  palabras = [palabra1, palabra2, palabra3, palabra4, palabra5, palabra6, palabra7, palabra8];
  console.log(palabras);
}
MostrarPalabras();
